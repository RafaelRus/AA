Adem�s de la memoria y de la carpeta "material" pedidos en el enunciado del tutorial 1, ha sido adjuntada la carpeta "anexo" que,
aunque no lo pide en el enunciado, sirve para ejecutar el programa de forma directa y contiene el resto de archivos y del c�digo
fuente del jeugo Pac-Man.