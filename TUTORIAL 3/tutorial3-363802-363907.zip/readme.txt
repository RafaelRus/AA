
Además de la memoria y de los archivos pedidos en el enunciado del tutorial 3, ha sido adjuntada la carpeta "anexo1" y "anexo2",aunque no lo pide en el enunciado, pero quizá son importante :

-En el archivo anexo1 contendrá el archivo adult-data.arff, es el archivo que hay que usar en el ejercicio 1.(Porque si no tiene ese archivo, al abrir .kf y dar start sale errores, ya que no lograr el archivo ese)

-En el archivo anexo2 contendrá el codigo completo para sirve para ejecutar el programa de forma directa para ver el archivo .arff generar tras la ejecución del comando python busters.py -g RandomGhost -l openHunt.Y hay una cosa importante con respecto al archivo arff, es el parte de su cabecera, añadimos la cabecera de forma manual una vez finalizado todo. Y los none del distancia Manhathan hemos cambiado usando ctrl+H, y se sustituye todo por 0.
