python busters.py -p QLearningAgent -k 3 -l labAA4  -n 2 -t 0.000000000000001
python busters.py -p QLearningAgent -k 3 -l labAA3  -n 2 -t 0.000000000000001
python busters.py -p QLearningAgent -k 2 -l labAA2  -n 2 -t 0.000000000000001
python busters.py -p QLearningAgent  -n 2 -t 0.000000000000001
python busters.py -p QLearningAgent -k 1 -l labAA1  -n 2 -t 0.000000000000001
python busters.py -p QLearningAgent  -n 2 -t 0.000000000000001 -l openHunt
#python busters.py -p QLearningAgent -k 3 -l labAA5  -n 2 -t 0.000000000000001
