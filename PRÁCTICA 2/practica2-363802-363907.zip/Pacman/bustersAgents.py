# bustersAgents.py
# ----------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import util
from game import Agent
from game import Directions
from keyboardAgents import KeyboardAgent
import inference
import busters
from wekaI import Weka

class NullGraphics:
	"Placeholder for graphics"
	def initialize(self, state, isBlue = False):
		pass
	def update(self, state):
		pass
	def pause(self):
		pass
	def draw(self, state):
		pass
	def updateDistributions(self, dist):
		pass
	def finish(self):
		pass

class KeyboardInference(inference.InferenceModule):
	"""
	Basic inference module for use with the keyboard.
	"""
	def initializeUniformly(self, gameState):
		"Begin with a uniform distribution over ghost positions."
		self.beliefs = util.Counter()
		for p in self.legalPositions: self.beliefs[p] = 1.0
		self.beliefs.normalize()

	def observe(self, observation, gameState):
		noisyDistance = observation
		emissionModel = busters.getObservationDistribution(noisyDistance)
		pacmanPosition = gameState.getPacmanPosition()
		allPossible = util.Counter()
		for p in self.legalPositions:
			trueDistance = util.manhattanDistance(p, pacmanPosition)
			if emissionModel[trueDistance] > 0:
				allPossible[p] = 1.0
		allPossible.normalize()
		self.beliefs = allPossible

	def elapseTime(self, gameState):
		pass

	def getBeliefDistribution(self):
		return self.beliefs


class BustersAgent:
	"An agent that tracks and displays its beliefs about ghost positions."

	def __init__( self, index = 0, inference = "ExactInference", ghostAgents = None, observeEnable = True, elapseTimeEnable = True):
		inferenceType = util.lookup(inference, globals())
		self.inferenceModules = [inferenceType(a) for a in ghostAgents]
		self.observeEnable = observeEnable
		self.elapseTimeEnable = elapseTimeEnable
	def registerInitialState(self, gameState):
		"Initializes beliefs and inference modules"
		import __main__
		self.display = __main__._display
		for inference in self.inferenceModules:
			inference.initialize(gameState)
		self.ghostBeliefs = [inf.getBeliefDistribution() for inf in self.inferenceModules]
		self.firstMove = True

	def observationFunction(self, gameState):
		"Removes the ghost states from the gameState"
		agents = gameState.data.agentStates
		gameState.data.agentStates = [agents[0]] + [None for i in range(1, len(agents))]
		return gameState
	def writeQtable(self):
		pass
	def getAction(self, gameState):
		"Updates beliefs, then chooses an action based on updated beliefs."
		#for index, inf in enumerate(self.inferenceModules):
		#    if not self.firstMove and self.elapseTimeEnable:
		#        inf.elapseTime(gameState)
		#    self.firstMove = False
		#    if self.observeEnable:
		#        inf.observeState(gameState)
		#    self.ghostBeliefs[index] = inf.getBeliefDistribution()
		#self.display.updateDistributions(self.ghostBeliefs)
		return self.chooseAction(gameState)
	def chooseAction(self, gameState):
		"By default, a BustersAgent just stops.  This should be overridden."
		return Directions.STOP
class BustersKeyboardAgent(BustersAgent, KeyboardAgent):
	"An agent controlled by the keyboard that displays beliefs about ghost positions."

	def __init__(self, index = 0, inference = "KeyboardInference", ghostAgents = None):
		KeyboardAgent.__init__(self, index)
		BustersAgent.__init__(self, index, inference, ghostAgents)

	def getAction(self, gameState):
		return BustersAgent.getAction(self, gameState)

	def chooseAction(self, gameState):
		return KeyboardAgent.getAction(self, gameState)

from distanceCalculator import Distancer
from game import Actions
from game import Directions
import random, sys

'''Random PacMan Agent'''
class RandomPAgent(BustersAgent):

	def registerInitialState(self, gameState):
		BustersAgent.registerInitialState(self, gameState)
		self.distancer = Distancer(gameState.data.layout, False)

	''' Example of counting something'''
	def countFood(self, gameState):
		food = 0
		for width in gameState.data.food:
			for height in width:
				if(height == True):
					food = food + 1
		return food

	''' Print the layout'''
	def printGrid(self, gameState):
		table = ""
		##print(gameState.data.layout) ## Print by terminal
		for x in range(gameState.data.layout.width):
			for y in range(gameState.data.layout.height):
				food, walls = gameState.data.food, gameState.data.layout.walls
				table = table + gameState.data._foodWallStr(food[x][y], walls[x][y]) + ","
		table = table[:-1]
		return table

	def chooseAction(self, gameState):
		move = Directions.STOP
		legal = gameState.getLegalActions(0) ##Legal position from the pacman
		move_random = random.randint(0, 3)
		if   ( move_random == 0 ) and Directions.WEST in legal:  move = Directions.WEST
		if   ( move_random == 1 ) and Directions.EAST in legal: move = Directions.EAST
		if   ( move_random == 2 ) and Directions.NORTH in legal:   move = Directions.NORTH
		if   ( move_random == 3 ) and Directions.SOUTH in legal: move = Directions.SOUTH
		return move

class GreedyBustersAgent(BustersAgent):
	"An agent that charges the closest ghost."

	def registerInitialState(self, gameState):
		"Pre-computes the distance between every two points."
		BustersAgent.registerInitialState(self, gameState)
		self.distancer = Distancer(gameState.data.layout, False)

	def chooseAction(self, gameState):
		"""
		First computes the most likely position of each ghost that has
		not yet been captured, then chooses an action that brings
		Pacman closer to the closest ghost (according to mazeDistance!).

		To find the mazeDistance between any two positions, use:
		  self.distancer.getDistance(pos1, pos2)

		To find the successor position of a position after an action:
		  successorPosition = Actions.getSuccessor(position, action)

		livingGhostPositionDistributions, defined below, is a list of
		util.Counter objects equal to the position belief
		distributions for each of the ghosts that are still alive.  It
		is defined based on (these are implementation details about
		which you need not be concerned):

		  1) gameState.getLivingGhosts(), a list of booleans, one for each
			 agent, indicating whether or not the agent is alive.  Note
			 that pacman is always agent 0, so the ghosts are agents 1,
			 onwards (just as before).

		  2) self.ghostBeliefs, the list of belief distributions for each
			 of the ghosts (including ghosts that are not alive).  The
			 indices into this list should be 1 less than indices into the
			 gameState.getLivingGhosts() list.
		"""
		pacmanPosition = gameState.getPacmanPosition()
		legal = [a for a in gameState.getLegalPacmanActions()]
		livingGhosts = gameState.getLivingGhosts()
		livingGhostPositionDistributions = \
			[beliefs for i, beliefs in enumerate(self.ghostBeliefs)
			 if livingGhosts[i+1]]
		return Directions.EAST

class BasicAgentAA(BustersAgent):
	def registerInitialState(self, gameState):
		BustersAgent.registerInitialState(self, gameState)
		self.distancer = Distancer(gameState.data.layout, False)
		self.countActions = 0
		self.eje_s =[]
	''' Example of counting something'''
	def countFood(self, gameState):
		food = 0
		for width in gameState.data.food:
			for height in width:
				if(height == True):
					food = food + 1
		return food

	''' Print the layout'''
	def printGrid(self, gameState):
		table = ""
		#print(gameState.data.layout) ## Print by terminal
		for x in range(gameState.data.layout.width):
			for y in range(gameState.data.layout.height):
				food, walls = gameState.data.food, gameState.data.layout.walls
				table = table + gameState.data._foodWallStr(food[x][y], walls[x][y]) + ","
		table = table[:-1]
		return table

	def printInfo(self, gameState):
		print "---------------- TICK ", self.countActions, " --------------------------"
		# Dimensiones del mapa
		width, height = gameState.data.layout.width, gameState.data.layout.height
		print "Width: ", width, " Height: ", height
		# Posicion del Pacman
		print "Pacman position: ", gameState.getPacmanPosition()
		# Acciones legales de pacman en la posicion actual
		print "Legal actions: ", gameState.getLegalPacmanActions()
		# Direccion de pacman
		print "Pacman direction: ", gameState.data.agentStates[0].getDirection()
		# Numero de fantasmas
		print "Number of ghosts: ", gameState.getNumAgents() - 1
		# Fantasmas que estan vivos (el indice 0 del array que se devuelve corresponde a pacman y siempre es false)
		print "Living ghosts: ", gameState.getLivingGhosts()
		# Posicion de los fantasmas
		print "Ghosts positions: ", gameState.getGhostPositions()
		# Direciones de los fantasmas
		print "Ghosts directions: ", [gameState.getGhostDirections().get(i) for i in range(0, gameState.getNumAgents() - 1)]
		# Distancia de manhattan a los fantasmas
		print "Ghosts distances: ", gameState.data.ghostDistances
		# Puntos de comida restantes
		print "Pac dots: ", gameState.getNumFood()
		# Distancia de manhattan a la comida mas cercada
		print "Distance nearest pac dots: ", gameState.getDistanceNearestFood()
		# Paredes del mapa
		print "Map:  \n", gameState.getWalls()
		# Puntuacion
		print "Score: ", gameState.getScore()

	def calculator_dist(self, x1, y1, x2,y2):
		list_acciones =[]
		if x1 < x2 :
			list_acciones.append('East')
		elif x1 > x2:
			list_acciones.append('West')
		if y1 < y2 :
			list_acciones.append('North')
		elif y1 > y2 :
			list_acciones.append('South')
		return list_acciones
	def localizador(self, gameState,accion_p,x_p,y_p,xn,yn):
		x=x_p
		y=y_p
		if  accion_p=='East':
			x=x+1
		elif accion_p=='West':
			x=x-1
		elif accion_p =='North':
			y=y+1
		else:
			y=y-1
		if y !=y_p:
			xi = x
			xd = x-1
			for i in range(0,gameState.getWalls().width-1):
				rd=random.randint(0,1)
				if rd == 0:
					if xi < gameState.getWalls().width:
						if gameState.getWalls()[xi][y] is False:
							self.eje_s.append(xi)
							self.eje_s.append(y)
							break
						xi=xi+1
					else:
						if xd > 0:
							if gameState.getWalls()[xd][y] is False:
								self.eje_s.append(xd)
								self.eje_s.append(y)
								break
							xd=xd-1

				else:
					if xd > 0:
						if gameState.getWalls()[xd][y] is False:
							self.eje_s.append(xd)
							self.eje_s.append(y)
							break
						xd=xd-1
					else:
						if xi < gameState.getWalls().width:
							if gameState.getWalls()[xi][y] is False:
								self.eje_s.append(xi)
								self.eje_s.append(y)
								break
							xi=xi+1
		else:
			yi = y
			yd = y-1
			for i in range(0,gameState.getWalls().height-3):
				rd=random.randint(0,1)
				if rd == 0:
					if yi < gameState.getWalls().height:
						if gameState.getWalls()[x][yi] is False:
							self.eje_s.append(x)
							self.eje_s.append(yi)
							break
						yi=yi+1
					else:
						if yd > 2:
							if gameState.getWalls()[x][yd] is False:
								self.eje_s.append(x)
								self.eje_s.append(yd)
								break
							yd=yd-1
				else:
					if yd > 2:
							if gameState.getWalls()[x][yd] is False:
								self.eje_s.append(x)
								self.eje_s.append(yd)
								break
							yd=yd-1
					else:
						if yi < gameState.getWalls().height:
							if gameState.getWalls()[x][yi] is False:
								self.eje_s.append(x)
								self.eje_s.append(yi)
								break
							yi=yi+1
		return self.eje_s
	def chooseAction(self, gameState):
		self.countActions = self.countActions + 1
		self.printInfo(gameState)
		move = Directions.STOP
		legal = gameState.getLegalActions(0) ##Legal position from the pacman7
		legaccion = []
		controlador =0
		x1,y1 = gameState.getPacmanPosition()
		if len(self.eje_s)==2:
			if x1 ==self.eje_s[0]:
				controlador=controlador+1
			if y1 ==self.eje_s[1]:
				controlador=controlador+1
			if controlador == 2:
				self.eje_s=[]
		listaB=gameState.data.ghostDistances
		ListaC=sorted(gameState.data.ghostDistances)
		for num in range(0, gameState.getNumAgents() - 1):
				if gameState.data.ghostDistances[listaB.index(ListaC[num])] is not None:
					self.id_=gameState.data.ghostDistances.index(ListaC[num])
					break
		if(len(self.eje_s)) == 2:
			x2,y2 =self.eje_s
		else:
			x2,y2 = gameState.getGhostPositions()[self.id_]
		for d in self.calculator_dist(x1,y1, x2, y2):
			if d in legal:
				legaccion.append(d)
		if len(legaccion) >= 1:
			num_id= random.randint(0,len(legaccion)-1)
			move = legaccion[num_id]
		else :
			if len(self.calculator_dist(x1,y1, x2, y2)):
				self.eje_s=[]
				rd= random.randint(0, len(self.calculator_dist(x1,y1, x2, y2))-1)
				self.localizador(gameState,self.calculator_dist(x1,y1, x2, y2)[rd],x1,y1,x2,y2)
			newaccion=[]
			if len(self.eje_s)== 2:
				x2,y2=self.eje_s
				for d in self.calculator_dist(x1,y1, x2, y2):
					if d in legal:
						newaccion.append(d)
			if len(newaccion) :
				num_id= random.randint(0,len(newaccion)-1)
				move =newaccion[num_id]
			rd = random.randint(0,3)
			if rd ==0 or move is 'Stop':
				while True:
					xr = random.randint(0, len(gameState.getLegalPacmanActions())-1)
					if gameState.getLegalPacmanActions()[xr] is not 'Stop':
						move = gameState.getLegalPacmanActions()[xr]
						break
		return move
class WekaAgentAA(BustersAgent):
	def __init__( self, index = 0, inference = "ExactInference", ghostAgents = None, observeEnable = True, elapseTimeEnable = True):
		inferenceType = util.lookup(inference, globals())
		self.inferenceModules = [inferenceType(a) for a in ghostAgents]
		self.observeEnable = observeEnable
		self.elapseTimeEnable = elapseTimeEnable
		self.weka = Weka()
		self.weka.start_jvm()

	def registerInitialState(self, gameState):
		BustersAgent.registerInitialState(self, gameState)
		self.distancer = Distancer(gameState.data.layout, False)
		self.countActions = 0

	def pos_rel(self, gameState):
		listaB=gameState.data.ghostDistances
		ListaC=sorted(gameState.data.ghostDistances)
		for num in range(0, gameState.getNumAgents() - 1):
				if gameState.data.ghostDistances[listaB.index(ListaC[num])] is not None:
					id_=gameState.data.ghostDistances.index(ListaC[num])
					break
		x,y = gameState.getPacmanPosition()
		x1,y1 = gameState.getGhostPositions()[id_]
		lista_rel = []
		lista_rel.append(x-x1)
		lista_rel.append(y-y1)
		lista_rel.append(gameState.data.ghostDistances[id_])
		return lista_rel

	def pared(self,gameState):

		binum = ([0,1],[0,-1],[1,0],[-1,0])
		lista_pared_pacman = []
		x,y = gameState.getPacmanPosition()
		for d in binum :
			n,m=d
			if gameState.getWalls()[x+n][y+m] is True :
				lista_pared_pacman.append(1)
			else:
				lista_pared_pacman.append(0)
		return lista_pared_pacman

	def chooseAction(self, gameState):
		self.countActions = self.countActions + 1
		move = Directions.STOP
		legal = gameState.getLegalActions(0) ##Legal position from the pacman7
		legaccion = []
		x,y,mh=self.pos_rel(gameState)
		n,s,e,o =self.pared(gameState)
		x = [x,y,mh,n,s,e,o,self.afteraccion]
		move = self.weka.predict("./J48.model", x, "./training_keyboard_v3.arff")
		if move not in legal:
			while True:
				xr = random.randint(0, len(gameState.getLegalPacmanActions())-1)
				if gameState.getLegalPacmanActions()[xr] is not 'Stop':
					move = gameState.getLegalPacmanActions()[xr]
					break
		self.afteraccion=move
		return move
class QLearningAgent(BustersAgent):
	def __init__( self, index = 0, inference = "ExactInference", ghostAgents = None, observeEnable = True, elapseTimeEnable = True):
		BustersAgent.__init__(self, index, inference, ghostAgents)
		self.epsilon = 0.0
		self.alpha = 0.1
		self.discount = 0.75
		self.table_file = open("qtable.txt", "r+")
		self.q_table = self.readQtable()
		self.actions=[Directions.NORTH,Directions.SOUTH,Directions.WEST,Directions.EAST]
		self.region={Directions.NORTH:0,Directions.SOUTH:1,Directions.WEST:2,Directions.EAST:3}
		self.ConjAction={Directions.NORTH:0,Directions.SOUTH:1,Directions.WEST:2,Directions.EAST:3}
		self.PX=[]
		self.PY=[]
		self.reward=0
		self.lastState=None
		self.mov='Stop'
	def registerInitialState(self, gameState):
		BustersAgent.registerInitialState(self, gameState)
		self.distancer = Distancer(gameState.data.layout, False)
		self.countActions = 0
	def readQtable(self):
		"Read qtable from disc"
		table = self.table_file.readlines()
		q_table = []
		for i, line in enumerate(table):
			row = line.split()
			row = [float(x) for x in row]
			q_table.append(row)
		return q_table
	def writeQtable(self):
		self.table_file.seek(0)
		self.table_file.truncate()
		for line in self.q_table:
			for item in line:
				self.table_file.write(str(item)+" ")
			self.table_file.write("\n")
		self.table_file.close()
	def getQValue(self, state, action):
		position = self.computePosition(state)
		action_column = self.ConjAction[action]
		return self.q_table[position][action_column]
	def computePosition(self,state):
		return state[0]*2+state[1]
	def computeValueFromQValues(self, state):
		return max([self.getQValue(state, action) for action in self.actions])
	def computeActionFromQValues(self, state):
		acs = util.Counter()
		for action in self.actions:
			acs[action]=self.getQValue(state, action)
		return acs.argMax()
	def getPolicy(self, state):
		return self.computeActionFromQValues(state)

	def getValue(self, state):
		return self.computeValueFromQValues(state)
	def getAc(self, state):
		flip = util.flipCoin(self.epsilon)
		if flip:
			return random.choice(self.actions)
		return self.getPolicy(state)
	def chooseAction(self, gameState):
		self.countActions = self.countActions + 1
		move = Directions.STOP
		LE=0
		self.legal = gameState.getLegalActions(0)
		self.legal.remove(Directions.STOP)
		state=self.statecalculador(gameState)
		move=self.getAc(state)
		for i in self.legal:
				if move== i:
					LE=1
		reward=self.recompensa(state,move)
		if LE == 0:
			move=random.choice(self.legal)
		if self.lastState != None:
			print "**************"+str(self.countActions)+"****************************"
			print "estado tick:"+str(self.lastState)+"\n"
			print "accion:"+str(move)+"\n"
			print "estado tick siguiente:"+str(state)+"\n"
			print "Refuerzo:"+str(reward)+"\n"
			print "******************************************"
			self.update(self.lastState,self.mov,state,self.reward)
		self.reward=reward
		self.lastState=state
		self.mov=move
		return move
	def recompensa(self,state,action):
		reward =0
		if state[0] == 0:
			if state[1]== 1 :
				if action =='North':
					reward=-30
				elif action=='East' or action=='West':
					reward=8
				else:
					reward=-12
			else:
				if action=='North':
					reward=6
				else:
					reward=-25
		elif state[0] == 1:
			if state[1]== 1 :
				if action =='South':
					reward=-30
				elif action=='East' or action=='West':
					reward=8
				else:
					reward=-12
			else:
				if action=='South':
					reward=6
				else:
					reward=-25
		elif state[0] == 2:
			if state[1]== 1 :
				if action =='West':
					reward=-30
				elif action=='North' or action=='South':
					reward=8
				else:
					reward=-12
			else:
				if action=='West':
					reward=6
				else:
					reward=-25
		else:
			if state[1]== 1 :
				if action =='East':
					reward=-30
				elif action=='North' or action=='South':
					reward=8
				else:
					reward=-12
			else:
				if action=='East':
					reward=6
				else:
					reward=-25
		return reward
	def statecalculador(self,gameState):
		stateAc=[]
		list_L=[]
		listaB=gameState.data.ghostDistances
		ListaC=sorted(gameState.data.ghostDistances)
		for num in range(0, gameState.getNumAgents() - 1):
				if gameState.data.ghostDistances[listaB.index(ListaC[num])] is not None:
					id_c=gameState.data.ghostDistances.index(ListaC[num])
					break
		z=0
		n=[]
		state_p=[]
		x,y=gameState.getPacmanPosition()
		if len(self.PX)!=0 and len(self.PY)!=0:
			if x == self.PX[len(self.PX)-1] and  y == self.PY[len(self.PY)-1]:
				ppx=self.PX.pop()
				ppy=self.PY.pop()
		if len(self.PX)!=0 and len(self.PY)!=0:
			list_L=self.cal2(gameState,self.PX[len(self.PX)-1],self.PY[len(self.PY)-1])
		else:
			list_L=self.Calculator(gameState,id_c)
		if len(list_L)>0:
			for i in list_L:
				for j in self.legal:
					if i == j:
						n.append(i)
			if len(n)==0:
				rd=random.randint(0,len(list_L)-1)
				state_p.append(self.region[list_L[rd]])
				self.determinarNewState(gameState,self.region[list_L[0]])
				state_p.append(1)
			else:
				rd=random.randint(0,len(n)-1)
				state_p.append(self.region[n[rd]])
				state_p.append(0)
		else:
			list_L=self.Calculator(gameState,id_c)
			if len(list_L)>0:
				for i in list_L:
					for j in self.legal:
						if i == j:
							n.append(i)
			if len(n)==0:
				rd=random.randint(0,len(list_L)-1)
				state_p.append(self.region[list_L[rd]])
				state_p.append(1)
				self.determinarNewState(gameState,self.region[list_L[0]])
			else:
				rd=random.randint(0,len(n)-1)
				state_p.append(self.region[n[rd]])
				state_p.append(0)
		return state_p
	def determinarNewState(self,gameState,action):
		x,y=gameState.getPacmanPosition()
		x11=x
		y11=y
		if  action==3:
			x11=x11+1
		elif action==2:
			x11=x11-1
		elif action ==0:
			y11=y11+1
		else:
			y11=y11-1
		if y !=y11:
			xi = x + 1
			xd = x-1
			for i in range(0,gameState.getWalls().width-2):
				rd=random.randint(0,1)
				if rd == 0:
					if xi < gameState.getWalls().width:
						if gameState.getWalls()[xi][y11] is False:
							self.PX.append(xi)
							self.PY.append(y11)
							break
						xi=xi+1
					else:
						if xd > 0:
							if gameState.getWalls()[xd][y11] is False:
								self.PX.append(xd)
								self.PY.append(y11)
								break
							xd=xd-1

				else:
					if xd > 0:
						if gameState.getWalls()[xd][y11] is False:
							self.PX.append(xd)
							self.PY.append(y11)
							break
						xd=xd-1
					else:
						if xi < gameState.getWalls().width:
							if gameState.getWalls()[xi][y11] is False:
								self.PX.append(xi)
								self.PY.append(y11)
								break
							xi=xi+1
		else:
			yi = y + 1
			yd = y-1
			for i in range(0,gameState.getWalls().height-2):
				rd=random.randint(0,1)
				if rd == 0:
					if yi < gameState.getWalls().height:
						if gameState.getWalls()[x11][yi] is False:
							self.PX.append(x11)
							self.PX.append(yi)
							break
						yi=yi+1
					else:
						if yd > 3:
							if gameState.getWalls()[x11][yd] is False:
								self.PX.append(x11)
								self.PX.append(yd)
								break
							yd=yd-1
				else:
					if yd > 3:
							if gameState.getWalls()[x11][yd] is False:
								self.PX.append(x11)
								self.PX.append(yd)
								break
							yd=yd-1
					else:
						if yi < gameState.getWalls().height:
							if gameState.getWalls()[x11][yi] is False:
								self.PX.append(x11)
								self.PX.append(yi)
								break
							yi=yi+1

	def cal2(self,gameState,x1,y1):
		x,y=gameState.getPacmanPosition()
		list_state =[]
		rd=random.randint(0,1)
		if abs(x-x1) < abs(y-y1) or rd==0:
			if y<y1:
				list_state.append('North')
			elif y>y1:
				list_state.append('South')
			if x<x1:
				list_state.append('East')
			elif x>x1:
				list_state.append('West')
		else:
			if y<y1:
				list_state.append('North')
			elif y>y1:
				list_state.append('South')
			if x<x1:
				list_state.append('East')
			elif x>x1:
				list_state.append('West')
		return list_state
	def Calculator(self,gameState,id_c):
		a=gameState.getDistanceNearestFood()
		b=gameState.getGhostPositions()[id_c]
		x,y=gameState.getPacmanPosition()
		list_state =[]
		if(a==None or a*2>b):
			x1,y1=gameState.getGhostPositions()[id_c]
		else:
			x1,y1=gameState.getPosNearestFood()
		rd=random.randint(0,1)
		if abs(x-x1) < abs(y-y1) or rd==0:
			if y<y1:
				list_state.append('North')
			elif y>y1:
				list_state.append('South')
			if x<x1:
				list_state.append('East')
			elif x>x1:
				list_state.append('West')
		else:
			if y<y1:
				list_state.append('North')
			elif y>y1:
				list_state.append('South')
			if x<x1:
				list_state.append('East')
			elif x>x1:
				list_state.append('West')
		return list_state
	def update(self, state, action,nextState,reward):
		id_a=self.computePosition(state)
		l=self.ConjAction[action]
		self.q_table[id_a][l]=(1-self.alpha)*self.q_table[id_a][l]+self.alpha * (reward+self.discount * self.getValue(nextState))
