import os.path
archivo = "qtable.txt"
f = open(archivo, 'w')
fd=['N','S','W','E']
cd=[0,1]



for ii in range (len(fd)):#*512
	for jj in range(len(cd)):
		result=ii*2+jj
		print str(result)+":"+str(fd[ii])+":"+str(cd[jj])
		f.write("0.0 0.0 0.0 0.0\n")
f.close()
