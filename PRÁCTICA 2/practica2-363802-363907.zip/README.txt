En la carpeta Pacman está todos los códigos y archivos modificados y necesarios para la ejecucuón del pacman  de aprendizaje por refuerzo
Para la competencia usamos el pacman desarrollando en la práctica 2:
El comando para ejecutar ese:        python busters.py -p QLearningAgent 
