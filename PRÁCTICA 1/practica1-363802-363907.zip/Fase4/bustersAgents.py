# bustersAgents.py
# ----------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import util
from game import Agent
from game import Directions
from keyboardAgents import KeyboardAgent
import inference
import busters
from wekaI import Weka

class NullGraphics:
	"Placeholder for graphics"
	def initialize(self, state, isBlue = False):
		pass
	def update(self, state):
		pass
	def pause(self):
		pass
	def draw(self, state):
		pass
	def updateDistributions(self, dist):
		pass
	def finish(self):
		pass

class KeyboardInference(inference.InferenceModule):
	"""
	Basic inference module for use with the keyboard.
	"""
	def initializeUniformly(self, gameState):
		"Begin with a uniform distribution over ghost positions."
		self.beliefs = util.Counter()
		for p in self.legalPositions: self.beliefs[p] = 1.0
		self.beliefs.normalize()

	def observe(self, observation, gameState):
		noisyDistance = observation
		emissionModel = busters.getObservationDistribution(noisyDistance)
		pacmanPosition = gameState.getPacmanPosition()
		allPossible = util.Counter()
		for p in self.legalPositions:
			trueDistance = util.manhattanDistance(p, pacmanPosition)
			if emissionModel[trueDistance] > 0:
				allPossible[p] = 1.0
		allPossible.normalize()
		self.beliefs = allPossible

	def elapseTime(self, gameState):
		pass

	def getBeliefDistribution(self):
		return self.beliefs


class BustersAgent:
	"An agent that tracks and displays its beliefs about ghost positions."

	def __init__( self, index = 0, inference = "ExactInference", ghostAgents = None, observeEnable = True, elapseTimeEnable = True):
		inferenceType = util.lookup(inference, globals())
		self.inferenceModules = [inferenceType(a) for a in ghostAgents]
		self.observeEnable = observeEnable
		self.elapseTimeEnable = elapseTimeEnable
	def registerInitialState(self, gameState):
		"Initializes beliefs and inference modules"
		import __main__
		self.display = __main__._display
		for inference in self.inferenceModules:
			inference.initialize(gameState)
		self.ghostBeliefs = [inf.getBeliefDistribution() for inf in self.inferenceModules]
		self.firstMove = True

	def observationFunction(self, gameState):
		"Removes the ghost states from the gameState"
		agents = gameState.data.agentStates
		gameState.data.agentStates = [agents[0]] + [None for i in range(1, len(agents))]
		return gameState

	def getAction(self, gameState):
		"Updates beliefs, then chooses an action based on updated beliefs."
		#for index, inf in enumerate(self.inferenceModules):
		#    if not self.firstMove and self.elapseTimeEnable:
		#        inf.elapseTime(gameState)
		#    self.firstMove = False
		#    if self.observeEnable:
		#        inf.observeState(gameState)
		#    self.ghostBeliefs[index] = inf.getBeliefDistribution()
		#self.display.updateDistributions(self.ghostBeliefs)
		return self.chooseAction(gameState)
	def indice(self, gameState):
		listaB=gameState.data.ghostDistances
		ListaC=sorted(gameState.data.ghostDistances)
		for num in range(0, gameState.getNumAgents() - 1):
				if gameState.data.ghostDistances[listaB.index(ListaC[num])] is not None:
					id_=gameState.data.ghostDistances.index(ListaC[num])
					break
		return id_
	def chooseAction(self, gameState):
		"By default, a BustersAgent just stops.  This should be overridden."
		return Directions.STOP

	def printLineData(self, gameState):
		archivo = "Explore.arff"
		import os.path
		if os.path.exists(archivo):
			f = open(archivo, 'a')
		else:
			f = open(archivo, 'w')
			f.write("@relation Explore\n")
			f.write("\n")
			f.write("@attribute PosRelX numeric\n")
			f.write("@attribute PosRelY numeric\n")
			f.write("@attribute ManhathanGP numeric\n")
			f.write("@attribute isParedN numeric\n")
			f.write("@attribute isParedS numeric\n")
			f.write("@attribute isParedE numeric\n")
			f.write("@attribute isParedO numeric\n")
			f.write("@attribute N_Food numeric\n")
			f.write("@attribute manhattan_Food numeric\n")
			f.write("@attribute PuntuacionActual numeric\n")
			f.write("@attribute PuntuacionSiguiente numeric\n")
			f.write("@attribute before_direccion {Stop,North,South,East,West}\n")
			f.write("@attribute direction {North,South,East,West}\n")
			f.write("\n")
			f.write("@data\n")


		nearestDot = gameState.getDistanceNearestFood()
		if nearestDot is None:
			nearestDot = -1
		# Si es el primer tick, no escribo, si no es, escribo
		if self.countActions == 0:
			self.before_accion ='Stop'
			self.bbefore_accion ='Stop'
			self.position = [0,0]
		if self.countActions != 0:
			# Limpio la cadena del tick anterior
			result = ""
			if self.before_accion!='Stop':
				for i in range(0, len(self.ss)):
					if self.ss[i] == '[' or self.ss[i] == '(' or self.ss[i] == ')'\
					or self.ss[i] == ']' or self.ss[i] == ' ':
						continue
					result += self.ss[i]
				# Anyado la puntuacion actual
				result +=str(gameState.getScore())+','+self.bbefore_accion+','+ self.before_accion+"\n"
		# Escribo la linea del tick anterior junto a la puntuacion actual
			f.write(result)
			f.close()
		id_s=self.indice(gameState)
		if gameState.data.agentStates[0].getDirection() != 'Stop':
			binum = ([0,1],[0,-1],[1,0],[-1,0])
			lista_pared_pacman = []
			for d in binum :
				n,m=d
				if gameState.getWalls()[self.x+n][self.y+m] is True :
					lista_pared_pacman.append(1)
				else:
					lista_pared_pacman.append(0)
			# Tengo que guardar la linea del tick actual para usarlo en el siguiente
			self.ss = str(self.pos_) +',' +str(self.manhattanPG)+ ',' \
			+str(lista_pared_pacman)+','+str(gameState.getNumFood())+','+str(nearestDot)+\
			','+str(gameState.getScore())+','
		self.bbefore_accion = self.before_accion
		self.before_accion = gameState.data.agentStates[0].getDirection()
		self.x,self.y = gameState.getPacmanPosition()
		x1,y1=gameState.getGhostPositions()[id_s]
		self.pos_=[]
		self.pos_.append(self.x-x1)
		self.pos_.append(self.y-y1)
		self.manhattanPG=gameState.data.ghostDistances[id_s]
class BustersKeyboardAgent(BustersAgent, KeyboardAgent):
	"An agent controlled by the keyboard that displays beliefs about ghost positions."

	def __init__(self, index = 0, inference = "KeyboardInference", ghostAgents = None):
		KeyboardAgent.__init__(self, index)
		BustersAgent.__init__(self, index, inference, ghostAgents)

	def getAction(self, gameState):
		return BustersAgent.getAction(self, gameState)

	def chooseAction(self, gameState):
		return KeyboardAgent.getAction(self, gameState)

from distanceCalculator import Distancer
from game import Actions
from game import Directions
import random, sys

'''Random PacMan Agent'''
class RandomPAgent(BustersAgent):

	def registerInitialState(self, gameState):
		BustersAgent.registerInitialState(self, gameState)
		self.distancer = Distancer(gameState.data.layout, False)

	''' Example of counting something'''
	def countFood(self, gameState):
		food = 0
		for width in gameState.data.food:
			for height in width:
				if(height == True):
					food = food + 1
		return food

	''' Print the layout'''
	def printGrid(self, gameState):
		table = ""
		##print(gameState.data.layout) ## Print by terminal
		for x in range(gameState.data.layout.width):
			for y in range(gameState.data.layout.height):
				food, walls = gameState.data.food, gameState.data.layout.walls
				table = table + gameState.data._foodWallStr(food[x][y], walls[x][y]) + ","
		table = table[:-1]
		return table

	def chooseAction(self, gameState):
		move = Directions.STOP
		legal = gameState.getLegalActions(0) ##Legal position from the pacman
		move_random = random.randint(0, 3)
		if   ( move_random == 0 ) and Directions.WEST in legal:  move = Directions.WEST
		if   ( move_random == 1 ) and Directions.EAST in legal: move = Directions.EAST
		if   ( move_random == 2 ) and Directions.NORTH in legal:   move = Directions.NORTH
		if   ( move_random == 3 ) and Directions.SOUTH in legal: move = Directions.SOUTH
		return move

class GreedyBustersAgent(BustersAgent):
	"An agent that charges the closest ghost."

	def registerInitialState(self, gameState):
		"Pre-computes the distance between every two points."
		BustersAgent.registerInitialState(self, gameState)
		self.distancer = Distancer(gameState.data.layout, False)

	def chooseAction(self, gameState):
		"""
		First computes the most likely position of each ghost that has
		not yet been captured, then chooses an action that brings
		Pacman closer to the closest ghost (according to mazeDistance!).

		To find the mazeDistance between any two positions, use:
		  self.distancer.getDistance(pos1, pos2)

		To find the successor position of a position after an action:
		  successorPosition = Actions.getSuccessor(position, action)

		livingGhostPositionDistributions, defined below, is a list of
		util.Counter objects equal to the position belief
		distributions for each of the ghosts that are still alive.  It
		is defined based on (these are implementation details about
		which you need not be concerned):

		  1) gameState.getLivingGhosts(), a list of booleans, one for each
			 agent, indicating whether or not the agent is alive.  Note
			 that pacman is always agent 0, so the ghosts are agents 1,
			 onwards (just as before).

		  2) self.ghostBeliefs, the list of belief distributions for each
			 of the ghosts (including ghosts that are not alive).  The
			 indices into this list should be 1 less than indices into the
			 gameState.getLivingGhosts() list.
		"""
		pacmanPosition = gameState.getPacmanPosition()
		legal = [a for a in gameState.getLegalPacmanActions()]
		livingGhosts = gameState.getLivingGhosts()
		livingGhostPositionDistributions = \
			[beliefs for i, beliefs in enumerate(self.ghostBeliefs)
			 if livingGhosts[i+1]]
		return Directions.EAST

class BasicAgentAA(BustersAgent):
	def registerInitialState(self, gameState):
		BustersAgent.registerInitialState(self, gameState)
		self.distancer = Distancer(gameState.data.layout, False)
		self.countActions = 0
		self.eje_s =[]

	''' Example of counting something'''
	def countFood(self, gameState):
		food = 0
		for width in gameState.data.food:
			for height in width:
				if(height == True):
					food = food + 1
		return food

	''' Print the layout'''
	def printGrid(self, gameState):
		table = ""
		#print(gameState.data.layout) ## Print by terminal
		for x in range(gameState.data.layout.width):
			for y in range(gameState.data.layout.height):
				food, walls = gameState.data.food, gameState.data.layout.walls
				table = table + gameState.data._foodWallStr(food[x][y], walls[x][y]) + ","
		table = table[:-1]
		return table

	def printInfo(self, gameState):
		print "---------------- TICK ", self.countActions, " --------------------------"
		# Dimensiones del mapa
		width, height = gameState.data.layout.width, gameState.data.layout.height
		print "Width: ", width, " Height: ", height
		# Posicion del Pacman
		print "Pacman position: ", gameState.getPacmanPosition()
		# Acciones legales de pacman en la posicion actual
		print "Legal actions: ", gameState.getLegalPacmanActions()
		# Direccion de pacman
		print "Pacman direction: ", gameState.data.agentStates[0].getDirection()
		# Numero de fantasmas
		print "Number of ghosts: ", gameState.getNumAgents() - 1
		# Fantasmas que estan vivos (el indice 0 del array que se devuelve corresponde a pacman y siempre es false)
		print "Living ghosts: ", gameState.getLivingGhosts()
		# Posicion de los fantasmas
		print "Ghosts positions: ", gameState.getGhostPositions()
		# Direciones de los fantasmas
		print "Ghosts directions: ", [gameState.getGhostDirections().get(i) for i in range(0, gameState.getNumAgents() - 1)]
		# Distancia de manhattan a los fantasmas
		print "Ghosts distances: ", gameState.data.ghostDistances
		# Puntos de comida restantes
		print "Pac dots: ", gameState.getNumFood()
		# Distancia de manhattan a la comida mas cercada
		print "Distance nearest pac dots: ", gameState.getDistanceNearestFood()
		# Paredes del mapa
		print "Map:  \n", gameState.getWalls()
		# Puntuacion
		print "Score: ", gameState.getScore()

	def calculator_dist(self, x1, y1, x2,y2):
		list_acciones =[]
		if x1 < x2 :
			list_acciones.append('East')
		elif x1 > x2:
			list_acciones.append('West')
		if y1 < y2 :
			list_acciones.append('North')
		elif y1 > y2 :
			list_acciones.append('South')
		return list_acciones
	def localizador(self, gameState,accion_p,x_p,y_p,xn,yn):
		x=x_p
		y=y_p
		if  accion_p=='East':
			x=x+1
		elif accion_p=='West':
			x=x-1
		elif accion_p =='North':
			y=y+1
		else:
			y=y-1
		if y !=y_p:
			xi = x
			xd = x-1
			for i in range(0,gameState.getWalls().width-1):
				rd=random.randint(0,1)
				if rd == 0:
					if xi < gameState.getWalls().width:
						if gameState.getWalls()[xi][y] is False:
							self.eje_s.append(xi)
							self.eje_s.append(y)
							break
						xi=xi+1
					else:
						if xd > 0:
							if gameState.getWalls()[xd][y] is False:
								self.eje_s.append(xd)
								self.eje_s.append(y)
								break
							xd=xd-1

				else:
					if xd > 0:
						if gameState.getWalls()[xd][y] is False:
							self.eje_s.append(xd)
							self.eje_s.append(y)
							break
						xd=xd-1
					else:
						if xi < gameState.getWalls().width:
							if gameState.getWalls()[xi][y] is False:
								self.eje_s.append(xi)
								self.eje_s.append(y)
								break
							xi=xi+1
		else:
			yi = y
			yd = y-1
			for i in range(0,gameState.getWalls().height-3):
				rd=random.randint(0,1)
				if rd == 0:
					if yi < gameState.getWalls().height:
						if gameState.getWalls()[x][yi] is False:
							self.eje_s.append(x)
							self.eje_s.append(yi)
							break
						yi=yi+1
					else:
						if yd > 2:
							if gameState.getWalls()[x][yd] is False:
								self.eje_s.append(x)
								self.eje_s.append(yd)
								break
							yd=yd-1
				else:
					if yd > 2:
							if gameState.getWalls()[x][yd] is False:
								self.eje_s.append(x)
								self.eje_s.append(yd)
								break
							yd=yd-1
					else:
						if yi < gameState.getWalls().height:
							if gameState.getWalls()[x][yi] is False:
								self.eje_s.append(x)
								self.eje_s.append(yi)
								break
							yi=yi+1
		return self.eje_s
	def chooseAction(self, gameState):
		self.countActions = self.countActions + 1
		self.printInfo(gameState)
		move = Directions.STOP
		legal = gameState.getLegalActions(0) ##Legal position from the pacman7
		legaccion = []
		controlador =0
		x1,y1 = gameState.getPacmanPosition()
		if len(self.eje_s)==2:
			if x1 ==self.eje_s[0]:
				controlador=controlador+1
			if y1 ==self.eje_s[1]:
				controlador=controlador+1
			if controlador == 2:
				self.eje_s=[]
		listaB=gameState.data.ghostDistances
		ListaC=sorted(gameState.data.ghostDistances)
		for num in range(0, gameState.getNumAgents() - 1):
				if gameState.data.ghostDistances[listaB.index(ListaC[num])] is not None:
					self.id_=gameState.data.ghostDistances.index(ListaC[num])
					break
		if(len(self.eje_s)) == 2:
			x2,y2 =self.eje_s
		else:
			x2,y2 = gameState.getGhostPositions()[self.id_]
		for d in self.calculator_dist(x1,y1, x2, y2):
			if d in legal:
				legaccion.append(d)
		if len(legaccion) >= 1:
			num_id= random.randint(0,len(legaccion)-1)
			move = legaccion[num_id]
		else :
			if len(self.calculator_dist(x1,y1, x2, y2)):
				self.eje_s=[]
				rd= random.randint(0, len(self.calculator_dist(x1,y1, x2, y2))-1)
				self.localizador(gameState,self.calculator_dist(x1,y1, x2, y2)[rd],x1,y1,x2,y2)
			newaccion=[]
			if len(self.eje_s)== 2:
				x2,y2=self.eje_s
				for d in self.calculator_dist(x1,y1, x2, y2):
					if d in legal:
						newaccion.append(d)
			if len(newaccion) :
				num_id= random.randint(0,len(newaccion)-1)
				move =newaccion[num_id]
			rd = random.randint(0,3)
			if rd ==0 or move is 'Stop':
				while True:
					xr = random.randint(0, len(gameState.getLegalPacmanActions())-1)
					if gameState.getLegalPacmanActions()[xr] is not 'Stop':
						move = gameState.getLegalPacmanActions()[xr]
						break
		return move
class WekaAgentAA(BustersAgent):
	def __init__( self, index = 0, inference = "ExactInference", ghostAgents = None, observeEnable = True, elapseTimeEnable = True):
		inferenceType = util.lookup(inference, globals())
		self.inferenceModules = [inferenceType(a) for a in ghostAgents]
		self.observeEnable = observeEnable
		self.elapseTimeEnable = elapseTimeEnable
		self.weka = Weka()
		self.weka.start_jvm()

	def registerInitialState(self, gameState):
		BustersAgent.registerInitialState(self, gameState)
		self.distancer = Distancer(gameState.data.layout, False)
		self.countActions = 0
		self.afteraccion = Directions.STOP

	def pos_rel(self, gameState):
		listaB=gameState.data.ghostDistances
		ListaC=sorted(gameState.data.ghostDistances)
		for num in range(0, gameState.getNumAgents() - 1):
				if gameState.data.ghostDistances[listaB.index(ListaC[num])] is not None:
					id_=gameState.data.ghostDistances.index(ListaC[num])
					break
		x,y = gameState.getPacmanPosition()
		x1,y1 = gameState.getGhostPositions()[id_]
		lista_rel = []
		lista_rel.append(x-x1)
		lista_rel.append(y-y1)
		lista_rel.append(gameState.data.ghostDistances[id_])
		return lista_rel

	def pared(self,gameState):

		binum = ([0,1],[0,-1],[1,0],[-1,0])
		lista_pared_pacman = []
		x,y = gameState.getPacmanPosition()
		for d in binum :
			n,m=d
			if gameState.getWalls()[x+n][y+m] is True :
				lista_pared_pacman.append(1)
			else:
				lista_pared_pacman.append(0)
		return lista_pared_pacman

	def chooseAction(self, gameState):
		self.countActions = self.countActions + 1
		move = Directions.STOP
		legal = gameState.getLegalActions(0) ##Legal position from the pacman7
		legaccion = []
		x,y,mh=self.pos_rel(gameState)
		n,s,e,o =self.pared(gameState)
		x = [x,y,mh,n,s,e,o,self.afteraccion]
		move = self.weka.predict("./J48.model", x, "./training_keyboard_v3.arff")
		if move not in legal:
			while True:
				xr = random.randint(0, len(gameState.getLegalPacmanActions())-1)
				if gameState.getLegalPacmanActions()[xr] is not 'Stop':
					move = gameState.getLegalPacmanActions()[xr]
					break
		self.afteraccion=move
		return move
