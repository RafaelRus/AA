#!/bin/bash
# Es bash usado para crear fichero de entrenanamiento del Pacman Programado
python busters.py -p BasicAgentAA -l a -g RandomGhost -t 0.0001 -n 2
python busters.py -p BasicAgentAA -l a -t 0.0001 -n 2
python busters.py -p BasicAgentAA -l a2 -g RandomGhost -t 0.0001 -n 2
python busters.py -p BasicAgentAA -l openHunt -g RandomGhost -t 0.0001 -n 2
python busters.py -p BasicAgentAA -l a1 -t 0.0001 -n 2
python busters.py -p BasicAgentAA -l a3 -t 0.0001 -n 2
python busters.py -p BasicAgentAA -l openHunt -t 0.0001 -n 2
python busters.py -p BasicAgentAA -l a1 -g RandomGhost -t 0.0001 -n 2
python busters.py -p BasicAgentAA -l a2 -t 0.0001 -n 2
python busters.py -p BasicAgentAA -l a3 -g RandomGhost -t 0.0001 -n 2