#!/bin/bash
# Es bash usado para crear fichero de test del teclado con mismos 5 mapas
python busters.py -l openHunt -g RandomGhost -t 2
python busters.py -l a1 -t 2
python busters.py -l a2 -g RandomGhost -t 2
python busters.py -l a3 -g RandomGhost -t 2
python busters.py -l a -g RandomGhost -t 2
python busters.py -l a -t 2	
python busters.py -l a2 -t 2
python busters.py -l a3 -t 2	
python busters.py -l openHunt -t 2	
python busters.py -l a1 -g RandomGhost -t 2