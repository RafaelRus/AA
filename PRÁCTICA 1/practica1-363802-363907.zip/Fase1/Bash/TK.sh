#!/bin/bash
# Es bash usado para crear fichero de entrenanamiento del teclado
python busters.py -l a -g RandomGhost  -n 2 -t 2
python busters.py -l a  -n 2 -t 2
python busters.py -l a2 -g RandomGhost  -n 2 -t 2
python busters.py -l openHunt -g RandomGhost  -n 2 -t 2
python busters.py -l a1  -n 2 -t 2
python busters.py -l a3  -n 2 -t 2
python busters.py -l openHunt  -n 2 -t 2
python busters.py -l a1 -g RandomGhost  -n 2　-t 2
python busters.py -l a2  -n 2　-t 2
python busters.py -l a3 -g RandomGhost  -n 2　-t 2