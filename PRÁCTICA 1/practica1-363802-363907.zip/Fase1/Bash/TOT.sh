#!/bin/bash
# Es bash usado para crear fichero de test con Pacman Programado con los 5 mapas diferentes usado para entrenamiento
python busters.py -p BasicAgentAA -g RandomGhost -t 0.0001 
python busters.py -p BasicAgentAA -l b1 -t 0.0001 
python busters.py -p BasicAgentAA -l b2 -g RandomGhost -t 0.0001 
python busters.py -p BasicAgentAA -l b3 -g RandomGhost -t 0.0001 
python busters.py -p BasicAgentAA -l smallHunt -g RandomGhost -t 0.0001 
python busters.py -p BasicAgentAA -l smallHunt -t 0.0001 	
python busters.py -p BasicAgentAA -l b2 -t 0.0001
python busters.py -p BasicAgentAA -l b3 -t 0.0001 	
python busters.py -p BasicAgentAA -t 0.0001 	
python busters.py -p BasicAgentAA -l b1 -g RandomGhost -t 0.0001