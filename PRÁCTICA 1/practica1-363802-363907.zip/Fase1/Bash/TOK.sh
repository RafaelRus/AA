#!/bin/bash
# Es bash usado para crear fichero de test con teclado con los 5 mapas diferentes usado para entrenamiento
python busters.py -g RandomGhost -t 2
python busters.py -l b1 -t 2
python busters.py -l b2 -g RandomGhost -t 2
python busters.py -l b3 -g RandomGhost -t 2
python busters.py -l smallHunt -g RandomGhost -t 2
python busters.py -l smallHunt -t 2	
python busters.py -l b2 -t 2
python busters.py -l b3 -t 2	
python busters.py -t 2	
python busters.py -l b1 -g RandomGhost -t 2