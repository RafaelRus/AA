#!/bin/bash

echo "Selecciona uno de las siguientes opciones"
echo "0.Pruebas de teclado"
echo "1.Pruebas de Pacman Programado"
echo "Aviso:Solo puedes Introducir 1 o 0 + enter"
read var1

if [ "$var1" -eq 0 ];
then
	    echo "Selecciona uno de las siguientes opciones para Pruebas con　teclado"
	    echo "0.Entrenamiento con teclado"
	    echo "1.Test de mismos mapas con teclado"
	    echo "2.Test de otros mapas con teclado"
	    echo "Aviso:Solo puedes Introducir 0,1 o 2 + enter"
	    read var2
		case "$var2" in
		      0)
			  bash ./Bash/TK.sh;;
		      1)
			  bash ./Bash/TSK.sh;;
		      2)
			  bash ./Bash/TOK.sh;;
		      3)
			  echo "Error de introduccion de datos,Hay que introducir bien los datos:SOLO PUEDES INTRODUCIR 0,1 O 2";;
		  esac	    		
else	
        echo "Selecciona uno de las siguientes opciones para Pruebas con　Pacman Programado"
        echo "0.Entrenamiento con Pacman Programado"
        echo "1.Test de mismos mapas con Pacman Programado"
        echo "2.Test de otros mapas con Pacman Programado"
        echo "Aviso:Solo puedes Introducir 0,1 o 2 + enter"
        read var2
       	case "$var2" in
		      0)
			  bash ./Bash/TT.sh;;
		      1)
			  bash ./Bash/TST.sh;;
		      2)
			  bash ./Bash/TOT.sh;;
		      3)
			  echo "Error de introduccion de datos,Hay que introducir bien los datos:SOLO PUEDES INTRODUCIR 0,1 O 2";;
		  esac	  
fi  	